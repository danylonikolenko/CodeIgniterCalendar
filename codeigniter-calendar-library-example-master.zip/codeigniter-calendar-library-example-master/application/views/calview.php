<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<link href="/./css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<link rel="stylesheet" type="text/css" href="/./css/bootstrap-datepicker.css" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Bootstrap core CSS -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.7/css/mdb.min.css" rel="stylesheet">

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


</head>

<link href="/./css/styletable.css" rel="stylesheet">

<style type="text/css">


</style>
<body>

<nav class="mb-1 navbar grey darken-4 navbar-expand-lg navbar-dark info-color">
<a class="navbar-brand" href="#">My Blog</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
		aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
	<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse"  id="navbarSupportedContent-4">
	<ul class="navbar-nav ml-auto">
		<li class="nav-item active">
			<a class="nav-link" href="#">
				<i class="fab fa-facebook-f"></i> Facebook
				<span class="sr-only">(current)</span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="https://www.instagram.com/_zbuntowany/">
				<i class="fab fa-instagram"></i> Instagram</a>
		</li>

	</ul>
</div>
</nav>


<div id="tittleName" style="text-align: center;  font-family: oblique;font-weight: bold; color: white;font-size: 56px; margin-top: 20px;" >
	Calendarъ
</div>




	<div id="containerCalendar">
		<div class="ar">
			<?php echo $calender; ?>
		</div>

	</div>

<div class="modalsize">
<div id = "myModal" class="modal" style=" width: 100%">
	<form method="POST" action="">
	<div class="modal-content" style="position: absolute; left: 0; right: 0; width: 500px; height: 250px; font-size: 14px; ">
		<span class="close" style="position: absolute; top: 0; right: 0; margin: 8px;">&times;</span>

		<p><h3>Событие:</h3></p>




		<div class="dates" style="color: black; background-color: white">

			<input  type="text"  class="d1"  class="form-control" id="usr1" name="event_date"  placeholder="yyy-mm-dd" autocomplete="on"  style="width: 100%;" >
		</div>

		<textarea name="name" placeholder="Событие" style="margin-top: 10px"></textarea>

		<input class="subbut" type="submit" value="Записать событие " name="submit" /><br />

	</div>
		</form>


	<?php


	if(isset($_POST["submit"])) {


		// Переменные с формы
		$name = $_POST['name'];
		$time = $_POST['event_date'];

		$db_host = "localhost";
		$db_user = "root"; // Логин БД
		$db_password = "123"; // Пароль БД
		$db_base = 'ci3'; // Имя БД
		$db_table = "calendar"; // Имя Таблицы БД

		$mysqli = mysqli_connect($db_host, $db_user, $db_password, $db_base);

		if(strlen($name)!=0){
			$mysqli->query("INSERT INTO `calendar` (`date`,`content`) VALUES ('$time','$name')");

		}
		echo "<meta http-equiv='refresh' content='0'>";






    }


	?>
</div>
</div>

<script>
    var modal = document.getElementById('myModal');
    var btn = document.getElementsByTagName("td")[0];
    var span = document.getElementsByClassName("close")[0];


    $(function (){


    });
$('td').click(function(){



     //console.log(
		// <?php
		// echo " $calender ";
		// ?>
	 //);
    // var day = $(this).date();

	//
    // $.ajax({
    //     url: "mycal/date_content",
    //     type: "POST",
    //     data: {num: day}
    // }).done(function(dsad){
	// 	alert(dsad);
	// }).fail(function(){
	//
	// });*/


    modal.style.display = "block"

    var w = $(this).find('td').text();
    console.log(w);

});




span.onclick = function () {
    modal.style.display = "none";
};

window.onclick = function (event) {
	if(event.target == modal){
	    modal.style.display = "none";
	}
}

</script>


<footer class="page-footer font-small foot grey darken-4 " style=" margin-top: 60px;">

	<!-- Copyright -->
	<div class="footer-copyright text-center py-3">© 2018 Copyright:
		<a href="https://mdbootstrap.com/education/bootstrap/"> MDBootstrap.com</a>
	</div>
	<!-- Copyright -->

</footer>
<script
	src="https://code.jquery.com/jquery-migrate-1.2.1.js"
	integrity="sha256-WFZLwje2g/SCw6gt7wWfJ7K+QRCdI316I4AHS1tPIr4="
	crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.7/js/mdb.min.js"></script>
<script src="/./node_modules/moment/min/moment.min.js"></script>
<script type="text/javascript" src="/./css/bootstrap-datepicker.js"></script>
<script src="/./script.js"></script>
<script src="/./fun.js"></script>

</body>
</html>
