


$(function() {

    $('.dates #usr1').datepicker({

        'format': 'yyyy-mm-dd',
        'autoclose': true,
		firstDayOfWeek:2


    });




    $(".d1").datepicker('setDate', new Date());




});










