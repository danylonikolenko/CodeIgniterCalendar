//
//
// var date1;
// var date2;
//
// var dateObj2;
// var dateObj1;
// var rez1;
// var rez2 ;
//
//
//
// //c
//
// function addd2(){
//
//     rez1 = moment(date2).subtract(1, 'd');
//     console.log(moment(rez1).format("DD/MM/YYYY"));
//     dateObj2 = new Date(rez1);
//     $(".d1").datepicker("setDate", dateObj2);
//
//
// }
//
//
// function addd1(){
//     rez2 = moment(date1).add(1, 'd');
//     console.log(moment(rez2).format("DD/MM/YYYY"));
//     dateObj1 = new Date(rez2);
//     $(".d2").datepicker("setDate", dateObj1);
// }
//
//
// $('.d2 ').change(function count () {
//
//
//     date2 = (moment($(".d2").datepicker("getDate")));
//
//
//     if (moment(date2).isAfter(date1)) {
//        addd2();
//
//     }
//
//     else if (moment(date2).isBefore(date1)) {
//
//        addd2();
//
//
//     }
//
//
//
// });
//
//
//
// $('.d1 ').change(function () {
//
//
//
//     date1 = (moment($(".d1").datepicker("getDate")));
//
//
//     if (moment(date1).isAfter(date2)) {
//
//         addd1();
//
//
//     }
//
//     if (moment(date1).isBefore(date2)) {
//
//
//
//     }
//
//
//
// });
//
//
//
//
//
